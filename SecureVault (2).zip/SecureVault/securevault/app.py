"""
SecureVault — Secure Cookie & Digital Signature System
=======================================================
Part A : HMAC-SHA256 cookie protection
Part B : RSA-2048 key-pair generation, file signing, verification
Bonus  : Key Substitution & Message/Key Substitution attacks (Wong p.150)
"""

import os, hashlib, hmac, time
from datetime import datetime
from flask import Flask, render_template, request, redirect, make_response
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.exceptions import InvalidSignature

app = Flask(__name__)
app.jinja_env.globals["enumerate"] = enumerate

# ─── PART A: secret key — NEVER leaves the server ────────────────────────────
SECRET_KEY = b'my_super_secret_key_never_share'

# ─── PART B: in-memory key store + signed files ──────────────────────────────
KEY_STORE   = {"private_key": None, "public_key": None}
# FIX: store original_content separately so tamper mode always modifies a fresh copy
SIGNED_FILES = {}   # filename → {"original_content": bytes, "signature": bytes}

os.makedirs("uploads",      exist_ok=True)
os.makedirs("signed_files", exist_ok=True)   # FIX: folder for disk storage


# =============================================================================
# PART A — HMAC helpers
# =============================================================================

def make_mac(payload: str) -> str:
    """Compute HMAC-SHA256 of payload using server secret."""
    return hmac.new(SECRET_KEY, payload.encode(), hashlib.sha256).hexdigest()

def check_mac(payload: str, received: str) -> bool:
    """Constant-time comparison to prevent timing attacks."""
    return hmac.compare_digest(make_mac(payload), received)


# =============================================================================
# PART A — Routes
# =============================================================================

@app.route("/")
def index():
    return redirect("/login")

# FIX 1: role is assigned server-side — user never selects it
USERS = {
    "alice": {"password": "password123", "role": "user"},
    "bob":   {"password": "password123", "role": "user"},
    "carol": {"password": "password123", "role": "user"},
}

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","").strip()

        user = USERS.get(username)
        if not user or user["password"] != password:
            return render_template("login.html", error="Invalid username or password.")

        role    = user["role"]                           # server decides the role
        expires = str(int(time.time()) + 300)            # 5-minute session
        payload = f"{username}|{role}|{expires}"
        mac     = make_mac(payload)

        resp = make_response(redirect("/dashboard"))
        resp.set_cookie("auth_data", payload, httponly=True, samesite="Strict")
        resp.set_cookie("auth_mac",  mac,     httponly=True, samesite="Strict")
        return resp

    return render_template("login.html")

@app.route("/logout")
def logout():
    resp = make_response(redirect("/login"))
    resp.delete_cookie("auth_data")
    resp.delete_cookie("auth_mac")
    return resp

@app.route("/dashboard")
def dashboard():
    payload = request.cookies.get("auth_data")
    mac     = request.cookies.get("auth_mac")

    if not payload or not mac:
        return render_template("alert.html",
            title="Access Denied",
            reason="No session found. Please log in.",
            code=401), 401

    if not check_mac(payload, mac):
        return render_template("alert.html",
            title="Tampering Detected",
            reason="HMAC verification failed — cookie was modified after issuance.",
            code=403), 403

    try:
        username, role, expires = payload.split("|")
    except ValueError:
        return render_template("alert.html",
            title="Tampering Detected",
            reason="Cookie structure is malformed.",
            code=403), 403

    if int(expires) < int(time.time()):
        return render_template("alert.html",
            title="Session Expired",
            reason="Your session has expired. Please log in again.",
            code=403), 403

    expiry_str = datetime.fromtimestamp(int(expires)).strftime("%H:%M:%S")
    return render_template("dashboard.html",
        username=username, role=role,
        expiry=expiry_str, payload=payload, mac=mac)


# =============================================================================
# PART B — Key generation
# =============================================================================

@app.route("/vault")
def vault():
    return render_template("vault.html",
        pub_pem       = _pub_pem(),
        signed_files  = list(SIGNED_FILES.keys()),
        active_tab    = "keys")

@app.route("/generate-keys", methods=["POST"])
def generate_keys():
    """
    Generate a fresh RSA-2048 key pair.
    One pair per session — all sign/verify operations use this same pair.
    """
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    KEY_STORE["private_key"] = priv
    KEY_STORE["public_key"]  = priv.public_key()
    SIGNED_FILES.clear()          # old signatures are now invalid

    # FIX 2: save both keys to disk so the student can inspect them
    with open("signed_files/private_key.pem", "wb") as f:
        f.write(priv.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()))
    with open("signed_files/public_key.pem", "wb") as f:
        f.write(priv.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo))

    fingerprint = hashlib.sha256(
        KEY_STORE["public_key"].public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo
        )
    ).hexdigest()

    return render_template("vault.html",
        pub_pem      = _pub_pem(),
        signed_files = list(SIGNED_FILES.keys()),
        active_tab   = "keys",
        msg          = f"RSA-2048 key pair generated. Fingerprint: {fingerprint[:32]}… "
                       f"Keys saved to signed_files/",
        msg_type     = "success")


# =============================================================================
# PART B — Sign
# =============================================================================

@app.route("/sign-file", methods=["POST"])
def sign_file():
    if not KEY_STORE["private_key"]:
        return _vault_msg("keys", "Generate a key pair first.", "danger")

    f = request.files.get("file")
    if not f or f.filename == "":
        return _vault_msg("sign", "No file selected.", "danger")

    content   = f.read()
    filename  = f.filename

    # RSA-PSS with SHA-256  (PSS is more secure than PKCS1v15 for signing)
    signature = KEY_STORE["private_key"].sign(
        content,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )

    # FIX: key renamed to original_content so tamper mode always uses the real original
    SIGNED_FILES[filename] = {"original_content": content, "signature": signature}

    # FIX 2: save file + signature + public key to disk
    safe = filename.replace("/", "_")
    with open(f"signed_files/{safe}", "wb") as fh:
        fh.write(content)
    with open(f"signed_files/{safe}.sig", "wb") as fh:
        fh.write(signature)
    with open(f"signed_files/{safe}.pubkey.pem", "wb") as fh:
        fh.write(KEY_STORE["public_key"].public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo))

    return render_template("vault.html",
        pub_pem      = _pub_pem(),
        signed_files = list(SIGNED_FILES.keys()),
        active_tab   = "sign",
        msg          = f"File '{filename}' signed and saved to signed_files/.",
        msg_type     = "success",
        sig_hex      = signature.hex()[:96] + "…")


# =============================================================================
# PART B — Verify
# mode="original"  → verify stored original_content       → must PASS  (req 3)
# mode="tampered"  → append extra bytes, then verify      → must FAIL  (req 4/5)
#
# FIX 3: always read from original_content so tamper mode is always a fresh
#        modification — not accumulating with previous tamper calls.
# =============================================================================

@app.route("/verify-file", methods=["POST"])
def verify_file():
    filename = request.form.get("filename")
    mode     = request.form.get("mode", "original")

    if not filename or filename not in SIGNED_FILES:
        return _vault_msg("verify", "File not found. Sign a file first.", "danger")

    stored_sig      = SIGNED_FILES[filename]["signature"]
    original_content = SIGNED_FILES[filename]["original_content"]   # FIX: use original_content

    if mode == "original":
        data = original_content
    else:
        # Simulate: someone opened the file on disk and added a line
        data = original_content + b"\n[*** FILE TAMPERED - LINE ADDED AFTER SIGNING ***]"

    try:
        KEY_STORE["public_key"].verify(
            stored_sig, data,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256()
        )
        result = {"ok": True,  "msg": f"✓ Signature VALID — '{filename}' is authentic and unmodified."}
    except InvalidSignature:
        result = {"ok": False, "msg": f"✕ Signature INVALID — file was modified after signing. Tampering detected!"}

    return render_template("vault.html",
        pub_pem      = _pub_pem(),
        signed_files = list(SIGNED_FILES.keys()),
        active_tab   = "verify",
        verify_result = result)


# =============================================================================
# BONUS — Key Substitution Attack  (Wong p.150)
# =============================================================================

@app.route("/attack/key-sub", methods=["POST"])
def attack_key_sub():
    message = request.form.get("message", "Grant admin access").encode()

    atk_priv = rsa.generate_private_key(65537, 2048)
    atk_pub  = atk_priv.public_key()
    atk_sig  = atk_priv.sign(
        message,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )

    try:
        atk_pub.verify(atk_sig, message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256())
        passes = True
    except InvalidSignature:
        passes = False

    result = {
        "name":   "Key Substitution Attack",
        "passes": passes,
        "steps": [
            "Attacker generates their own RSA key pair (pk_A, sk_A)",
            "Attacker signs the forged message m' with sk_A → sig_A",
            "Attacker presents (pk_A, m', sig_A) to the verifier",
            "Verifier runs verify(pk_A, m', sig_A) — mathematically valid → PASSES",
        ],
        "why":  "Verification checks math only, not identity. pk_A was never certified.",
        "fix":  "Bind public keys to identities via X.509 certificates / PKI.",
        "msg":  message.decode(),
        "atk_pub": atk_pub.public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo).decode()[:300] + "…",
        "sig":  atk_sig.hex()[:80] + "…",
    }

    return render_template("vault.html",
        pub_pem=_pub_pem(), signed_files=list(SIGNED_FILES.keys()),
        active_tab="bonus", attack_result=result)


# =============================================================================
# BONUS — Message/Key Substitution Attack  (Wong p.150)
# =============================================================================

@app.route("/attack/msg-key-sub", methods=["POST"])
def attack_msg_key_sub():
    filename = request.form.get("filename")
    if not filename or filename not in SIGNED_FILES:
        return _vault_msg("bonus", "Sign a file first, then run this attack.", "danger")

    orig_content = SIGNED_FILES[filename]["original_content"]   # FIX: use original_content
    orig_sig     = SIGNED_FILES[filename]["signature"]
    forged       = orig_content + b"\n[FORGED - ADMIN PRIVILEGES GRANTED]"

    atk_priv = rsa.generate_private_key(65537, 2048)
    atk_pub  = atk_priv.public_key()
    atk_sig  = atk_priv.sign(
        forged,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )

    # Attack: verify forged with attacker key → PASSES
    try:
        atk_pub.verify(atk_sig, forged,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256())
        atk_passes = True
    except InvalidSignature:
        atk_passes = False

    # Control: verify forged with REAL server key → FAILS
    try:
        KEY_STORE["public_key"].verify(orig_sig, forged,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256())
        legit_passes = True
    except (InvalidSignature, Exception):
        legit_passes = False

    result = {
        "name":   "Message/Key Substitution Attack",
        "passes": atk_passes,
        "steps": [
            f"Starting from valid (m='{filename}', sig_original)",
            "Attacker creates forged content m' = m + '[FORGED…]'",
            "Attacker generates fresh key pair (pk_A, sk_A) and signs m' → sig_A",
            "Attacker presents (pk_A, m', sig_A) claiming pk_A is the server key",
            f"verify(pk_A, m', sig_A) → {'PASSES ← attack succeeds' if atk_passes else 'FAILS'}",
            f"verify(pk_server, m', sig_original) → {'PASSES' if legit_passes else 'FAILS ← correct, real key rejects tampered content'}",
        ],
        "why":  "No certificate binding — verifier accepts any pk presented by attacker.",
        "fix":  "Use PKI / X.509 to verify pk_A truly belongs to the legitimate signer.",
        "msg":  "[FORGED — ADMIN PRIVILEGES GRANTED]",
        "atk_pub": atk_pub.public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo).decode()[:300] + "…",
        "sig":  atk_sig.hex()[:80] + "…",
    }

    return render_template("vault.html",
        pub_pem=_pub_pem(), signed_files=list(SIGNED_FILES.keys()),
        active_tab="bonus", attack_result=result)


# ─── helpers ─────────────────────────────────────────────────────────────────

def _pub_pem():
    if KEY_STORE["public_key"] is None:
        return None
    return KEY_STORE["public_key"].public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode()

def _vault_msg(tab, msg, msg_type):
    return render_template("vault.html",
        pub_pem=_pub_pem(), signed_files=list(SIGNED_FILES.keys()),
        active_tab=tab, msg=msg, msg_type=msg_type)


@app.errorhandler(404)
def not_found(_): return redirect("/login")

if __name__ == "__main__":
    app.run(debug=True, port=5000)